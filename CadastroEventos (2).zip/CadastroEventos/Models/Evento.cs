using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace CadastroEventos.Models;

public class Evento : INotifyPropertyChanged
{
    private string _nome = string.Empty;
    private string _local = string.Empty;
    private DateTime _dataInicio = DateTime.Today;
    private DateTime _dataTermino = DateTime.Today;
    private int _numeroParticipantes = 1;
    private decimal _custoPorParticipante;

    public string Nome { get => _nome; set => Set(ref _nome, value); }
    public string Local { get => _local; set => Set(ref _local, value); }
    public DateTime DataInicio { get => _dataInicio; set { if (Set(ref _dataInicio, value)) AtualizarCalculos(); } }
    public DateTime DataTermino { get => _dataTermino; set { if (Set(ref _dataTermino, value)) AtualizarCalculos(); } }
    public int NumeroParticipantes { get => _numeroParticipantes; set { if (Set(ref _numeroParticipantes, value)) AtualizarCalculos(); } }
    public decimal CustoPorParticipante { get => _custoPorParticipante; set { if (Set(ref _custoPorParticipante, value)) AtualizarCalculos(); } }

    public TimeSpan Intervalo => DataTermino.Date - DataInicio.Date;
    // Contagem inclusiva: um evento que começa e termina no mesmo dia dura 1 dia.
    public int DuracaoDias => Intervalo.Days + 1;
    public decimal CustoTotal => NumeroParticipantes * CustoPorParticipante;
    public string DuracaoFormatada => $"{DuracaoDias} dia(s) (intervalo: {Intervalo.Days} dia(s))";

    public event PropertyChangedEventHandler? PropertyChanged;
    private bool Set<T>(ref T field, T value, [CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return false;
        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        return true;
    }
    private void AtualizarCalculos()
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Intervalo)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(DuracaoDias)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(DuracaoFormatada)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CustoTotal)));
    }
}
